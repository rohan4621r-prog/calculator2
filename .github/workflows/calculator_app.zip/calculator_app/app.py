from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import math
import re

app = Flask(__name__)
CORS(app)

# ── Safe math helpers ──────────────────────────────────────────────────────────

def factorial(n):
    n = int(round(n))
    if n < 0 or n > 170:
        raise ValueError("Factorial out of range")
    return math.factorial(n)

def npr(n, r):
    n, r = int(round(n)), int(round(r))
    if r > n or r < 0:
        raise ValueError("Invalid nPr values")
    return factorial(n) // factorial(n - r)

def ncr(n, r):
    n, r = int(round(n)), int(round(r))
    if r > n or r < 0:
        raise ValueError("Invalid nCr values")
    return math.comb(n, r)

def safe_log(x):
    if x <= 0:
        raise ValueError("log of non-positive number")
    return math.log10(x)

def safe_ln(x):
    if x <= 0:
        raise ValueError("ln of non-positive number")
    return math.log(x)

def safe_sqrt(x):
    if x < 0:
        raise ValueError("sqrt of negative number")
    return math.sqrt(x)

def safe_cbrt(x):
    return math.copysign(abs(x) ** (1/3), x)

def safe_tan(x):
    return math.tan(x)

SAFE_GLOBALS = {
    "__builtins__": {},
    "sin": math.sin,
    "cos": math.cos,
    "tan": safe_tan,
    "asin": math.asin,
    "acos": math.acos,
    "atan": math.atan,
    "sinh": math.sinh,
    "cosh": math.cosh,
    "tanh": math.tanh,
    "log": safe_log,
    "ln": safe_ln,
    "sqrt": safe_sqrt,
    "cbrt": safe_cbrt,
    "abs": abs,
    "pow": pow,
    "round": round,
    "ceil": math.ceil,
    "floor": math.floor,
    "fact": factorial,
    "nPr": npr,
    "nCr": ncr,
    "pi": math.pi,
    "e": math.e,
    "inf": math.inf,
}

# ── Expression sanitiser ───────────────────────────────────────────────────────

ALLOWED_PATTERN = re.compile(
    r'^[\d\s\+\-\*\/\.\(\)\^%eiπ,]'
    r'|sin|cos|tan|asin|acos|atan|sinh|cosh|tanh'
    r'|log|ln|sqrt|cbrt|abs|pow|round|ceil|floor'
    r'|fact|nPr|nCr|pi|inf'
)

BLOCKED = ["__", "import", "exec", "eval", "open", "os", "sys",
           "globals", "locals", "getattr", "setattr", "delattr",
           "compile", "input", "print", "lambda", "class", "def"]

def sanitise(expr: str) -> str:
    for word in BLOCKED:
        if word in expr:
            raise ValueError(f"Forbidden token: {word}")
    # Replace display tokens with Python-safe equivalents
    expr = expr.replace("^", "**")
    expr = expr.replace("×", "*")
    expr = expr.replace("÷", "/")
    expr = expr.replace("π", "pi")
    expr = expr.replace("E", "*10**")   # scientific notation
    return expr

# ── Format result ──────────────────────────────────────────────────────────────

def format_result(val):
    if isinstance(val, (int, float)):
        if not math.isfinite(val):
            raise ValueError("Result is Infinity or NaN")
        if isinstance(val, float) and val.is_integer() and abs(val) < 1e15:
            return str(int(val))
        # Trim floating-point noise
        formatted = f"{val:.12g}"
        return formatted
    return str(val)

# ── Routes ─────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/calculate", methods=["POST"])
def calculate():
    data = request.get_json(force=True)
    expression = data.get("expression", "").strip()
    angle_mode = data.get("angle_mode", "deg")   # "deg" or "rad"

    if not expression:
        return jsonify({"error": "Empty expression"}), 400

    try:
        clean = sanitise(expression)

        # Inject angle-aware trig if degree mode
        if angle_mode == "deg":
            DEG = math.pi / 180
            trig_env = {
                "sin": lambda x: math.sin(x * DEG),
                "cos": lambda x: math.cos(x * DEG),
                "tan": lambda x: math.tan(x * DEG),
                "asin": lambda x: math.degrees(math.asin(x)),
                "acos": lambda x: math.degrees(math.acos(x)),
                "atan": lambda x: math.degrees(math.atan(x)),
            }
            env = {**SAFE_GLOBALS, **trig_env}
        else:
            env = SAFE_GLOBALS.copy()

        result = eval(clean, env)           # noqa: S307 – sanitised above
        return jsonify({"result": format_result(result), "expression": expression})

    except ZeroDivisionError:
        return jsonify({"error": "Division by zero"}), 200
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 200
    except SyntaxError:
        return jsonify({"error": "Invalid expression"}), 200
    except Exception as exc:
        return jsonify({"error": f"Math error: {exc}"}), 200


@app.route("/constants", methods=["GET"])
def constants():
    return jsonify({
        "pi": str(math.pi),
        "e":  str(math.e),
        "phi": str((1 + math.sqrt(5)) / 2),
        "sqrt2": str(math.sqrt(2)),
    })


if __name__ == "__main__":
    app.run(debug=True, port=5000)
