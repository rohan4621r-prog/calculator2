// ── State ──────────────────────────────────────────────────────────────────────
const state = {
  expression: '',
  justCalced: false,
  memory:     0,
  hasMemory:  false,
  angleMode:  'deg',    // 'deg' | 'rad'
  history:    [],
  mode:       'basic',
  constants:  {},
};

// ── DOM refs ───────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const disp        = $('main-display');
const exprLine    = $('expr-line');
const memInd      = $('mem-indicator');
const angleModeEl = $('angle-mode');
const histList    = $('history-list');
const sciBlock    = $('sci-block');
const loadingEl   = $('loading-overlay');

// ── Init ───────────────────────────────────────────────────────────────────────
(async function init() {
  try {
    const res = await fetch('/constants');
    state.constants = await res.json();
  } catch (_) { /* offline – constants unavailable */ }
})();

// ── Mode ───────────────────────────────────────────────────────────────────────
function setMode(mode) {
  state.mode = mode;
  $('pill-basic').classList.toggle('active', mode === 'basic');
  $('pill-sci').classList.toggle('active',   mode === 'sci');
  sciBlock.classList.toggle('visible', mode === 'sci');
}

// ── Display helpers ────────────────────────────────────────────────────────────
function prettyExpr(raw) {
  return raw
    .replace(/\*\*/g, '^')
    .replace(/\*/g,   '×')
    .replace(/\//g,   '÷')
    .replace(/pi/g,   'π')
    .replace(/\bE\b/g,'E');
}

function setDisplay(val) {
  disp.className = 'main-display';
  disp.textContent = String(val);
}

function showError(msg) {
  disp.textContent  = msg;
  disp.className    = 'main-display error';
  setTimeout(() => setDisplay('0'), 1600);
}

function flashSuccess(val) {
  disp.textContent = val;
  disp.className   = 'main-display success';
  setTimeout(() => disp.classList.remove('success'), 600);
}

function updateExprLine() {
  exprLine.textContent = prettyExpr(state.expression).slice(-40);
  if (state.expression) {
    disp.className   = 'main-display';
    disp.textContent = prettyExpr(state.expression).slice(-22);
  }
}

// ── Input ──────────────────────────────────────────────────────────────────────
function inputToken(t) {
  if (state.justCalced) {
    const OPS = ['+', '-', '*', '/', '%', '**', 'E'];
    if (!OPS.includes(t)) state.expression = '';
    state.justCalced = false;
  }
  state.expression += t;
  updateExprLine();
}

function inputFn(fn) {
  if (state.justCalced) { state.expression = ''; state.justCalced = false; }
  state.expression += fn;
  updateExprLine();
}

function inputDot() {
  if (state.justCalced) { state.expression = '0'; state.justCalced = false; }
  const parts = state.expression.split(/[\+\-\*\/\(]/);
  const last  = parts[parts.length - 1];
  if (!last.includes('.')) state.expression += '.';
  updateExprLine();
}

function insertConstant(name) {
  const val = state.constants[name];
  if (!val) { inputToken(name); return; }
  if (state.justCalced) { state.expression = ''; state.justCalced = false; }
  state.expression += val;
  updateExprLine();
}

// ── Clear / Back ───────────────────────────────────────────────────────────────
function clearAll() {
  state.expression = ''; state.justCalced = false;
  exprLine.textContent = ''; setDisplay('0');
}
function clearEntry() {
  state.expression = ''; state.justCalced = false; setDisplay('0');
}
function backspace() {
  if (state.justCalced) { clearAll(); return; }
  state.expression = state.expression.slice(0, -1);
  if (!state.expression) setDisplay('0');
  else updateExprLine();
}

// ── Angle mode ─────────────────────────────────────────────────────────────────
function toggleAngle() {
  state.angleMode  = state.angleMode === 'deg' ? 'rad' : 'deg';
  const isDeg      = state.angleMode === 'deg';
  $('angle-btn').textContent = isDeg ? '→ RAD' : '→ DEG';
  angleModeEl.textContent    = isDeg ? 'DEG'   : 'RAD';
}

// ── Memory ─────────────────────────────────────────────────────────────────────
function memStore()  { state.memory = parseFloat(disp.textContent) || 0; state.hasMemory = true;  memInd.classList.add('visible'); }
function memRecall() {
  if (!state.hasMemory) return;
  state.expression = String(state.memory);
  state.justCalced = false;
  exprLine.textContent = ''; setDisplay(state.memory);
}
function memAdd()    { state.memory += parseFloat(disp.textContent) || 0; state.hasMemory = true;  memInd.classList.add('visible'); }
function memSub()    { state.memory -= parseFloat(disp.textContent) || 0; state.hasMemory = true;  memInd.classList.add('visible'); }
function memClear()  { state.memory = 0; state.hasMemory = false; memInd.classList.remove('visible'); }

// ── CALCULATE — calls Flask backend ───────────────────────────────────────────
async function calculate() {
  const expr = state.expression.trim();
  if (!expr) return;

  loadingEl.classList.add('active');

  try {
    const res  = await fetch('/calculate', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ expression: expr, angle_mode: state.angleMode }),
    });

    const data = await res.json();

    if (data.error) {
      showError(data.error);
      state.expression = ''; state.justCalced = false;
    } else {
      const result = data.result;
      exprLine.textContent = prettyExpr(expr) + '  =';
      flashSuccess(result);
      addHistory(expr, result);
      state.expression = result;
      state.justCalced = true;
    }
  } catch (err) {
    showError('Server error');
  } finally {
    loadingEl.classList.remove('active');
  }
}

// ── History ────────────────────────────────────────────────────────────────────
function addHistory(expr, result) {
  state.history.unshift({ expr, result });
  if (state.history.length > 60) state.history.pop();
  renderHistory();
}

function renderHistory() {
  if (!state.history.length) {
    histList.innerHTML = '<div class="hist-empty">NO HISTORY YET</div>';
    return;
  }
  histList.innerHTML = state.history.map((h, i) => `
    <div class="history-item" onclick="useHistory(${i})">
      <div class="hist-expr">${prettyExpr(h.expr)}</div>
      <div class="hist-result">${h.result}</div>
    </div>
  `).join('');
}

function useHistory(i) {
  state.expression = state.history[i].result;
  state.justCalced = true;
  exprLine.textContent = '';
  setDisplay(state.history[i].result);
}

function clearHistory() {
  state.history = [];
  renderHistory();
}

// ── Keyboard support ───────────────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.ctrlKey || e.metaKey) return;
  const k = e.key;
  if (k >= '0' && k <= '9') { inputToken(k); return; }
  const MAP = {
    '+': '+', '-': '-', '*': '*', '%': '%',
    '(': '(', ')': ')', '.': null,
    'Enter': null, '=': null,
    'Backspace': null, 'Escape': null, '/': null,
  };
  if (!(k in MAP) && !['Enter','Backspace','Escape','.'].includes(k)) return;
  e.preventDefault();
  if (k === '/')       inputToken('/');
  else if (k === '+')  inputToken('+');
  else if (k === '-')  inputToken('-');
  else if (k === '*')  inputToken('*');
  else if (k === '%')  inputToken('%');
  else if (k === '(')  inputToken('(');
  else if (k === ')')  inputToken(')');
  else if (k === '.')  inputDot();
  else if (k === 'Enter' || k === '=') calculate();
  else if (k === 'Backspace') backspace();
  else if (k === 'Escape')    clearAll();
});
