# CALC-X · Scientific Calculator
Python (Flask) backend + HTML/CSS/JS frontend

## Project Structure
```
calculator_app/
├── app.py               ← Flask backend (Python)
├── requirements.txt     ← Python dependencies
├── templates/
│   └── index.html       ← Frontend HTML
└── static/
    ├── style.css        ← Styles
    └── script.js        ← Frontend logic (JS)
```

## How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Start the Flask server
```bash
python app.py
```

### 3. Open in browser
```
http://localhost:5000
```

## Features
- **Basic mode** — arithmetic, parentheses, modulo, scientific notation (EXP)
- **Scientific mode** — sin/cos/tan (and inverses), log/ln, √/∛, |x|, ceil/floor,
  π, e, φ, √2, x², x³, xʸ, n!, nPr, nCr
- **Memory** — MS / MR / M+ / M− / MC
- **Degree ↔ Radian** toggle for trig functions
- **Calculation history** — click any past result to reuse it
- **Full keyboard support** — type expressions, Enter to evaluate, Escape to clear
- **Flask API endpoints**
  - `POST /calculate` — evaluates expression server-side in Python
  - `GET  /constants`  — returns π, e, φ, √2 to full precision

## API Usage (direct)
```bash
curl -X POST http://localhost:5000/calculate \
  -H "Content-Type: application/json" \
  -d '{"expression": "sin(30)", "angle_mode": "deg"}'

# Response:
# {"expression": "sin(30)", "result": "0.5"}
```
